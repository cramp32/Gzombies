AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Barricade"
ENT.Author = "Your Name"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/props_debris/wood_board04a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
    end

    self:SetHealth(100)
end

function ENT:OnTakeDamage(dmg)
    self:SetHealth(self:Health() - dmg:GetDamage())
    if self:Health() <= 0 then
        self:Break()
    end
end

function ENT:Break()
    self:SetCollisionGroup(COLLISION_GROUP_NONE)
    self:SetRenderMode(RENDERMODE_TRANSALPHA)
    self:SetColor(Color(255, 255, 255, 150)) -- Semi-transparent
    self:SetNotSolid(true)
end

function ENT:Use(activator, caller)
    if activator:IsPlayer() then
        local points = activator:GetNWInt("GZombies_Points", 0)
        if points >= 50 then -- Example cost to repair
            activator:SetNWInt("GZombies_Points", points - 50)
            self:SetHealth(100)
            self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
            self:SetRenderMode(RENDERMODE_NORMAL)
            self:SetColor(Color(255, 255, 255, 255)) -- Fully opaque
            self:SetNotSolid(false)
        else
            activator:ChatPrint("Not enough points to repair!")
        end
    end
end
