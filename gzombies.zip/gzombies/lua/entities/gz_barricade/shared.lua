ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Barricade"
ENT.Author = "Your Name"
ENT.Spawnable = true
