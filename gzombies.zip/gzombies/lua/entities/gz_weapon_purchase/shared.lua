ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Weapon Purchase"
ENT.Author = "Your Name"
ENT.Spawnable = true
