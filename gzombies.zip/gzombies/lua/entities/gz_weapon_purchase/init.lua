AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Weapon Purchase"
ENT.Author = "Your Name"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/props_c17/oildrum001.mdl")  -- Change to an appropriate model for a weapon purchase station
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false)
    end
end

function ENT:Use(activator, caller)
    if activator:IsPlayer() then
        local points = activator:GetNWInt("GZombies_Points", 0)
        if points >= 50 then  -- Example cost for the revolver
            activator:SetNWInt("GZombies_Points", points - 50)
            activator:Give("weapon_357")  -- Give the player the revolver
            activator:ChatPrint("You have purchased a revolver!")
        else
            activator:ChatPrint("Not enough points to purchase a revolver!")
        end
    end
end
