net.Receive("GZombies_StartWave", function()
    local wave = net.ReadInt(32)
    chat.AddText(Color(255, 0, 0), "Wave " .. wave .. " has started!")
end)

net.Receive("GZombies_PlayerPoints", function()
    local points = net.ReadInt(32)
    chat.AddText(Color(0, 255, 0), "Points: " .. points)
end)

net.Receive("GZombies_EndRound", function()
    local round = net.ReadInt(32)
    chat.AddText(Color(255, 255, 0), "Round " .. round .. " completed! New round starting soon.")
end)

net.Receive("GZombies_NewRound", function()
    local round = net.ReadInt(32)
    chat.AddText(Color(255, 0, 0), "Round " .. round .. " has started!")
end)
