if SERVER then
    AddCSLuaFile()

    -- Include server-side files
    include("gzombies_sv.lua")

    -- Register the barricade entity
    scripted_ents.Register({
        Type = "anim",
        Base = "base_gmodentity",
        PrintName = "Barricade",
        Author = "Your Name",
        Spawnable = true,

        Initialize = function(self)
            self:SetModel("models/props_debris/wood_board04a.mdl")
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetMoveType(MOVETYPE_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)

            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
            end

            self:SetHealth(100)
        end,

        OnTakeDamage = function(self, dmg)
            self:SetHealth(self:Health() - dmg:GetDamage())
            if self:Health() <= 0 then
                self:Break()
            end
        end,

        Break = function(self)
            self:SetCollisionGroup(COLLISION_GROUP_NONE)
            self:SetRenderMode(RENDERMODE_TRANSALPHA)
            self:SetColor(Color(255, 255, 255, 150)) -- Semi-transparent
            self:SetNotSolid(true)
        end,

        Use = function(self, activator, caller)
            if activator:IsPlayer() then
                local points = activator:GetNWInt("GZombies_Points", 0)
                if points >= 50 then -- Example cost to repair
                    activator:SetNWInt("GZombies_Points", points - 50)
                    self:SetHealth(100)
                    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
                    self:SetRenderMode(RENDERMODE_NORMAL)
                    self:SetColor(Color(255, 255, 255, 255)) -- Fully opaque
                    self:SetNotSolid(false)
                else
                    activator:ChatPrint("Not enough points to repair!")
                end
            end
        end
    }, "gz_barricade")
end

if CLIENT then
    -- Include client-side files
    include("gzombies_cl.lua")
end

-- Shared files
include("gzombies_shared.lua")
include("gzombies_menu.lua")
