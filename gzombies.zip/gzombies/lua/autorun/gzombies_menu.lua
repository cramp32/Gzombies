if CLIENT then
    local zombieCount = 10 -- Default value
    local spawnPoints = {}

    local function CreateControlPanel(panel)
        panel:ClearControls()

        local startButton = vgui.Create("DButton", panel)
        startButton:SetText("Start Game")
        startButton:SetSize(250, 40)
        startButton.DoClick = function()
            net.Start("GZombies_StartGame")
            net.SendToServer()
        end
        panel:AddItem(startButton)

        local stopButton = vgui.Create("DButton", panel)
        stopButton:SetText("Stop Game")
        stopButton:SetSize(250, 40)
        stopButton.DoClick = function()
            net.Start("GZombies_StopGame")
            net.SendToServer()
        end
        panel:AddItem(stopButton)

        local addSpawnButton = vgui.Create("DButton", panel)
        addSpawnButton:SetText("Add Spawn Point")
        addSpawnButton:SetSize(250, 40)
        addSpawnButton.DoClick = function()
            local trace = LocalPlayer():GetEyeTrace()
            table.insert(spawnPoints, trace.HitPos)
            net.Start("GZombies_AddSpawnPoint")
            net.WriteVector(trace.HitPos)
            net.SendToServer()
        end
        panel:AddItem(addSpawnButton)

        local removeSpawnButton = vgui.Create("DButton", panel)
        removeSpawnButton:SetText("Remove Last Spawn Point")
        removeSpawnButton:SetSize(250, 40)
        removeSpawnButton.DoClick = function()
            if #spawnPoints > 0 then
                table.remove(spawnPoints)
                net.Start("GZombies_RemoveLastSpawnPoint")
                net.SendToServer()
            else
                LocalPlayer():ChatPrint("No spawn points to remove!")
            end
        end
        panel:AddItem(removeSpawnButton)

        local clearSpawnPointsButton = vgui.Create("DButton", panel)
        clearSpawnPointsButton:SetText("Clear Spawn Points")
        clearSpawnPointsButton:SetSize(250, 40)
        clearSpawnPointsButton.DoClick = function()
            spawnPoints = {}
            net.Start("GZombies_ClearSpawnPoints")
            net.SendToServer()
        end
        panel:AddItem(clearSpawnPointsButton)

        local zombieSlider = vgui.Create("DNumSlider", panel)
        zombieSlider:SetText("Number of Zombies")
        zombieSlider:SetMin(1)
        zombieSlider:SetMax(50)
        zombieSlider:SetValue(zombieCount)
        zombieSlider:SetDecimals(0)
        zombieSlider.OnValueChanged = function(self, value)
            zombieCount = value
            net.Start("GZombies_SetZombieCount")
            net.WriteInt(zombieCount, 32)
            net.SendToServer()
        end
        panel:AddItem(zombieSlider)
    end

    hook.Add("AddToolMenuTabs", "GZOMBIES_AddToolMenuTabs", function()
        spawnmenu.AddToolTab("GZOMBIES", "GZOMBIES", "icon16/brick.png")
    end)

    hook.Add("AddToolMenuCategories", "GZOMBIES_AddToolMenuCategories", function()
        spawnmenu.AddToolCategory("GZOMBIES", "Admin", "Admin")
    end)

    hook.Add("PopulateToolMenu", "GZOMBIES_PopulateToolMenu", function()
        spawnmenu.AddToolMenuOption("GZOMBIES", "Admin", "GZOMBIES_ControlPanel", "Control Panel", "", "", function(panel)
            if LocalPlayer():IsAdmin() then
                CreateControlPanel(panel)
            else
                panel:Help("You must be an admin to access this panel.")
            end
        end)
    end)
end
