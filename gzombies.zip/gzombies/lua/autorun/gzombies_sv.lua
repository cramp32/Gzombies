util.AddNetworkString("GZombies_StartWave")
util.AddNetworkString("GZombies_PlayerPoints")
util.AddNetworkString("GZombies_EndRound")
util.AddNetworkString("GZombies_NewRound")
util.AddNetworkString("GZombies_AddSpawnPoint")
util.AddNetworkString("GZombies_ClearSpawnPoints")
util.AddNetworkString("GZombies_StartGame")
util.AddNetworkString("GZombies_StopGame")
util.AddNetworkString("GZombies_SetZombieCount")

local round = 0
local zombiesPerRound = 10
local activeZombies = 0
local gameActive = false

-- List of spawn points
local zombieSpawnPoints = {}

local function FindNearestTarget(zombie)
    local nearestTarget
    local nearestDistance = math.huge

    for _, ent in pairs(ents.FindInSphere(zombie:GetPos(), 2000)) do
        if (ent:IsPlayer() and ent:Alive()) or ent:GetClass() == "gz_barricade" then
            local distance = zombie:GetPos():DistToSqr(ent:GetPos())
            if distance < nearestDistance then
                nearestDistance = distance
                nearestTarget = ent
            end
        end
    end

    return nearestTarget
end

local function SetZombieTarget(zombie)
    local target = FindNearestTarget(zombie)
    if target then
        zombie:SetTarget(target)
        zombie:SetEnemy(target)
        zombie:SetSchedule(SCHED_CHASE_ENEMY)
    end
end

local function SpawnZombie()
    if #zombieSpawnPoints == 0 then return end -- Ensure there are spawn points
    local spawnPos = zombieSpawnPoints[math.random(#zombieSpawnPoints)]
    local zombieType = math.random(2) == 1 and "npc_zombie" or "npc_fastzombie" -- 50/50 chance to spawn a regular or fast zombie
    local zombie = ents.Create(zombieType)
    if IsValid(zombie) then
        zombie:SetPos(spawnPos)
        zombie:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER) -- Prevents collision with other zombies
        zombie:Spawn()
        SetZombieTarget(zombie)
        activeZombies = activeZombies + 1
    end
end

local function StartNextRound()
    if not gameActive then return end
    round = round + 1
    activeZombies = 0
    for i = 1, zombiesPerRound do
        SpawnZombie()
    end
    net.Start("GZombies_NewRound")
    net.WriteInt(round, 32)
    net.Broadcast()
end

hook.Add("OnNPCKilled", "GZombies_OnNPCKilled", function(npc, attacker)
    if attacker:IsPlayer() then
        local points = attacker:GetNWInt("GZombies_Points", 0) + 10
        attacker:SetNWInt("GZombies_Points", points)
        net.Start("GZombies_PlayerPoints")
        net.WriteInt(points, 32)
        net.Send(attacker)
    end
    activeZombies = activeZombies - 1
    if activeZombies <= 0 then
        timer.Simple(10, function() -- Intermission between rounds
            net.Start("GZombies_EndRound")
            net.WriteInt(round, 32)
            net.Broadcast()
            StartNextRound()
        end)
    end
end)

-- Start game
net.Receive("GZombies_StartGame", function(len, ply)
    if not ply:IsAdmin() then return end
    gameActive = true
    round = 0
    StartNextRound()
end)

-- Stop game
net.Receive("GZombies_StopGame", function(len, ply)
    if not ply:IsAdmin() then return end
    gameActive = false
    round = 0
    activeZombies = 0
    -- Remove all zombies
    for _, ent in pairs(ents.FindByClass("npc_zombie")) do
        ent:Remove()
    end
    for _, ent in pairs(ents.FindByClass("npc_fastzombie")) do
        ent:Remove()
    end
    net.Start("GZombies_EndRound")
    net.WriteInt(round, 32)
    net.Broadcast()
end)

-- Add spawn point
net.Receive("GZombies_AddSpawnPoint", function(len, ply)
    if not ply:IsAdmin() then return end
    local pos = net.ReadVector()
    table.insert(zombieSpawnPoints, pos)
    ply:ChatPrint("Added spawn point at: " .. tostring(pos))
end)

-- Clear spawn points
net.Receive("GZombies_ClearSpawnPoints", function(len, ply)
    if not ply:IsAdmin() then return end
    zombieSpawnPoints = {}
    ply:ChatPrint("All spawn points have been cleared.")
end)

-- Set zombie count
net.Receive("GZombies_SetZombieCount", function(len, ply)
    if not ply:IsAdmin() then return end
    zombiesPerRound = net.ReadInt(32)
    ply:ChatPrint("Number of zombies per round set to: " .. zombiesPerRound)
end)
