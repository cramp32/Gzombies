GM.Name = "GZOMBIES"
GM.Author = "Your Name"
GM.Email = "your.email@example.com"
GM.Website = "http://example.com"

function GM:Initialize()
    self.BaseClass.Initialize(self)
end
