AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "SMG Purchase"
ENT.Author = "Your Name"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/props_c17/oildrum001.mdl")  -- Change to an appropriate model for a weapon purchase station
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false)
    end
end

function ENT:Use(activator, caller)
    if activator:IsPlayer() then
        local points = activator:GetNWInt("GZombies_Points", 0)
        if points >= 100 then  -- Example cost for the SMG
            activator:SetNWInt("GZombies_Points", points - 100)
            activator:Give("weapon_smg1")  -- Give the player the SMG
            activator:ChatPrint("You have purchased an SMG!")
        else
            activator:ChatPrint("Not enough points to purchase an SMG!")
        end
    end
end
