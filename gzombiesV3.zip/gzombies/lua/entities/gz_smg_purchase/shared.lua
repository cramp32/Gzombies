ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "SMG Purchase"
ENT.Author = "Your Name"
ENT.Spawnable = true
