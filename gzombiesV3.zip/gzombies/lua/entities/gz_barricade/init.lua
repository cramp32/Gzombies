AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Barricade"
ENT.Author = "Your Name"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/props_debris/wood_board04a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false) -- Keep the barricade frozen in place initially
    end

    self:SetHealth(100)
    self.broken = false
end

function ENT:OnTakeDamage(dmg)
    self:SetHealth(self:Health() - dmg:GetDamage())
    if self:Health() <= 0 and not self.broken then
        self:Break()
    end
end

function ENT:Break()
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER) -- Collidable with player, not with NPCs
    self:SetRenderMode(RENDERMODE_TRANSALPHA)
    self:SetColor(Color(255, 255, 255, 150)) -- Semi-transparent
    self.broken = true
end

function ENT:Repair()
    self:SetHealth(100)
    self:SetCollisionGroup(COLLISION_GROUP_NONE) -- Reset collision to default
    self:SetRenderMode(RENDERMODE_NORMAL)
    self:SetColor(Color(255, 255, 255, 255)) -- Fully opaque
    self:SetNotSolid(false)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:EnableMotion(false) -- Freeze the barricade in place
    end

    self.broken = false
end

function ENT:Use(activator, caller)
    if activator:IsPlayer() then
        local points = activator:GetNWInt("GZombies_Points", 0)
        if points >= 10 then -- Example cost to repair
            activator:SetNWInt("GZombies_Points", points - 10)
            self:Repair()
        else
            activator:ChatPrint("Not enough points to repair!")
        end
    end
end

function ENT:Think()
    if not self.broken then
        for _, ent in pairs(ents.FindInSphere(self:GetPos(), 50)) do
            if ent:IsNPC() and (ent:GetClass() == "npc_zombie" or ent:GetClass() == "npc_fastzombie") then
                self:TakeDamage(10, ent, ent) -- Zombies deal damage to the barricade
                ent:SetSchedule(SCHED_MELEE_ATTACK1) -- Attack animation
            end
        end
    end
    self:NextThink(CurTime() + 1)
    return true
end
