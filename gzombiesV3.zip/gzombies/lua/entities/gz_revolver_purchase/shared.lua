ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Revolver Purchase"
ENT.Author = "Your Name"
ENT.Spawnable = true
