if SERVER then
    AddCSLuaFile()

    -- Include server-side files
    include("gzombies_sv.lua")

    -- Register the barricade entity
    scripted_ents.Register({
        Type = "anim",
        Base = "base_gmodentity",
        PrintName = "Barricade",
        Author = "Your Name",
        Spawnable = true,

        Initialize = function(self)
            self:SetModel("models/props_debris/wood_board04a.mdl")
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetMoveType(MOVETYPE_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
            self:SetUseType(SIMPLE_USE)

            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(false) -- Keep the barricade frozen in place initially
            end

            self:SetHealth(100)
            self.broken = false
        end,

        OnTakeDamage = function(self, dmg)
            self:SetHealth(self:Health() - dmg:GetDamage())
            if self:Health() <= 0 and not self.broken then
                self:Break()
            end
        end,

        Break = function(self)
            self:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER) -- Collidable with player, not with NPCs
            self:SetRenderMode(RENDERMODE_TRANSALPHA)
            self:SetColor(Color(255, 255, 255, 150)) -- Semi-transparent
            self.broken = true
        end,

        Repair = function(self)
            self:SetHealth(100)
            self:SetCollisionGroup(COLLISION_GROUP_NONE) -- Reset collision to default
            self:SetRenderMode(RENDERMODE_NORMAL)
            self:SetColor(Color(255, 255, 255, 255)) -- Fully opaque
            self:SetNotSolid(false)

            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(false) -- Freeze the barricade in place
            end

            self.broken = false
        end,

        Use = function(self, activator, caller)
            if activator:IsPlayer() then
                local points = activator:GetNWInt("GZombies_Points", 0)
                if points >= 10 then -- Example cost to repair
                    activator:SetNWInt("GZombies_Points", points - 10)
                    self:Repair()
                else
                    activator:ChatPrint("Not enough points to repair!")
                end
            end
        end,

        Think = function(self)
            if not self.broken then
                for _, ent in pairs(ents.FindInSphere(self:GetPos(), 50)) do
                    if ent:IsNPC() and (ent:GetClass() == "npc_zombie" or ent:GetClass() == "npc_fastzombie") then
                        self:TakeDamage(10, ent, ent) -- Zombies deal damage to the barricade
                        ent:SetSchedule(SCHED_MELEE_ATTACK1) -- Attack animation
                    end
                end
            end
            self:NextThink(CurTime() + 1)
            return true
        end
    }, "gz_barricade")

    -- Register the weapon purchase entities
    scripted_ents.Register({
        Type = "anim",
        Base = "base_gmodentity",
        PrintName = "SMG Purchase",
        Author = "Your Name",
        Spawnable = true,

        Initialize = function(self)
            self:SetModel("models/props_c17/oildrum001.mdl")  -- Change to an appropriate model for a weapon purchase station
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetMoveType(MOVETYPE_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
            self:SetUseType(SIMPLE_USE)

            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(false)
            end
        end,

        Use = function(self, activator, caller)
            if activator:IsPlayer() then
                local points = activator:GetNWInt("GZombies_Points", 0)
                if points >= 100 then  -- Example cost for the SMG
                    activator:SetNWInt("GZombies_Points", points - 100)
                    activator:Give("weapon_smg1")  -- Give the player the SMG
                    activator:ChatPrint("You have purchased an SMG!")
                else
                    activator:ChatPrint("Not enough points to purchase an SMG!")
                end
            end
        end
    }, "gz_smg_purchase")

    scripted_ents.Register({
        Type = "anim",
        Base = "base_gmodentity",
        PrintName = "Revolver Purchase",
        Author = "Your Name",
        Spawnable = true,

        Initialize = function(self)
            self:SetModel("models/props_c17/oildrum001.mdl")  -- Change to an appropriate model for a weapon purchase station
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetMoveType(MOVETYPE_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
            self:SetUseType(SIMPLE_USE)

            local phys = self:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:EnableMotion(false)
            end
        end,

        Use = function(self, activator, caller)
            if activator:IsPlayer() then
                local points = activator:GetNWInt("GZombies_Points", 0)
                if points >= 50 then  -- Example cost for the revolver
                    activator:SetNWInt("GZombies_Points", points - 50)
                    activator:Give("weapon_357")  -- Give the player the revolver
                    activator:ChatPrint("You have purchased a revolver!")
                else
                    activator:ChatPrint("Not enough points to purchase a revolver!")
                end
            end
        end
    }, "gz_revolver_purchase")
end

if CLIENT then
    -- Include client-side files
    include("gzombies_cl.lua")
end

-- Shared files
include("gzombies_shared.lua")
include("gzombies_menu.lua")
